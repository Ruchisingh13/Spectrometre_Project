﻿Imports MICRO_USB2_CLR_DLL
Imports System.Threading
Imports System.IO
Imports System.Windows.Forms.DataVisualization.Charting
Imports System.Linq
Imports System.Runtime.InteropServices
Imports System.IO.Ports

Public Class Form1
    ' First Spectrometer
    Dim g_lDevID_1 As Long
    Dim obuMICROUSB2_1 As New MICRO_USB2_CLR()

    ' Second Spectrometer
    Dim g_lDevID_2 As Long
    Dim obuMICROUSB2_2 As New MICRO_USB2_CLR()

    ' Initialization Code
    Dim aryusImageData(PIXEL_SIZE - 1) As UShort
    Dim arylTime(0) As ULong

    Dim lReturn As Long

    ' Constants
    Public Const EXPOSURE_TIME As Integer = 20000
    Public Const PIXEL_SIZE As Integer = 288

    ' Threads for Capturing
    Dim captureThread1 As Thread
    Dim captureThread2 As Thread

    ' Captured Data
    Dim capturedData1(PIXEL_SIZE - 1) As UShort
    Dim capturedData2(PIXEL_SIZE - 1) As UShort

    ' Graph Series for Two Spectrometers
    Private graphSeries1 As New Series("Intensity 1")
    Private graphSeries2 As New Series("Intensity 2")

    ' Capture Status
    Dim isCapturing As Boolean = False

    Dim wavelengths1(288 - 1) As Integer  ' For Spectrometer 1
    Dim wavelengths2(288 - 1) As Integer

    '' Coefficients for Spectrometer 1
    'Public A0_1 As Double = 304.349493963413
    'Public B1_1 As Double = 2.68852555790766
    'Public B2_1 As Double = -0.000855332088537141
    'Public B3_1 As Double = -0.0000094620758458323
    'Public B4_1 As Double = 0.0000000138925108579558
    'Public B5_1 As Double = 0.000000000000860288677236112

    '' Coefficients for Spectrometer 2
    'Public A0_2 As Double = 151.040043948869
    'Public B1_2 As Double = 1.39442003854191
    'Public B2_2 As Double = -0.000101837021369701
    'Public B3_2 As Double = -0.00000716028458736972
    'Public B4_2 As Double = 0.0000000138733712880187
    'Public B5_2 As Double = -0.00000000000690480263498571

    Public A0_1 As Double
    Public B1_1 As Double
    Public B2_1 As Double
    Public B3_1 As Double
    Public B4_1 As Double
    Public B5_1 As Double

    Public A0_2 As Double
    Public B1_2 As Double
    Public B2_2 As Double
    Public B3_2 As Double
    Public B4_2 As Double
    Public B5_2 As Double

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        cmbSpectrometerSelect.Items.Add("Spectrometer 1")
        cmbSpectrometerSelect.Items.Add("Spectrometer 2")

        ' Set default value to Spectrometer 1
        cmbSpectrometerSelect.SelectedIndex = 0

        ' Initialize Chart Series
        Chart1.Series.Clear()
        Chart2.Series.Clear()

        ' Configure First Spectrometer Graph Series
        graphSeries1.ChartType = SeriesChartType.Line
        graphSeries1.Color = Color.Blue
        graphSeries1.Name = "Spectrometer 1"
        Chart1.Series.Add(graphSeries1)

        ' Configure Second Spectrometer Graph Series
        graphSeries2.ChartType = SeriesChartType.Line
        graphSeries2.Color = Color.Red
        graphSeries2.Name = "Spectrometer 2"
        Chart1.Series.Add(graphSeries2)

        ' Disable Stop & Save buttons initially
        BtnStop.Enabled = False
        BtnSaveCSV.Enabled = False

    End Sub

    ''' =========================== 🚀 START CAPTURE =========================== '''
    Private Sub BtnStart_Click(sender As Object, e As EventArgs) Handles BtnStart.Click

        ' Check if capture threads are already running
        If captureThread1 IsNot Nothing AndAlso captureThread1.IsAlive Then
            MessageBox.Show("Spectrometer 1 capture is already running!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        If captureThread2 IsNot Nothing AndAlso captureThread2.IsAlive Then
            MessageBox.Show("Spectrometer 2 capture is already running!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        If isCapturing Then
            MessageBox.Show("Capturing is already in progress!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        isCapturing = True
        BtnStart.Enabled = False
        BtnStop.Enabled = True
        BtnSaveCSV.Enabled = False
        lblStatus.Text = "Status: Capturing..."

        'CalculateWavelengths()
        Dim selectedSpectrometer = cmbSpectrometerSelect.SelectedIndex

        Static isInitialized As Boolean = False

        If Not isInitialized Then
            lReturn = obuMICROUSB2_1.MICRO_USB2_initialize()
            If lReturn <> Usb2Struct.Cusb2Err.usb2Success Then
                MessageBox.Show("Initialization Failed!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
            isInitialized = True ' Mark as initialized
        End If

        ' ✅ Get Device Connection List
        Dim aryDeviceId(8) As Short
        Dim usNum As UShort
        lReturn = obuMICROUSB2_1.MICRO_USB2_getModuleConnectionList(aryDeviceId, usNum)
        If lReturn <> Usb2Struct.Cusb2Err.usb2Success OrElse usNum < (selectedSpectrometer + 1) Then
            MessageBox.Show("Less than two spectrometers detected!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        If selectedSpectrometer = 0 Then
            g_lDevID_1 = CLng(aryDeviceId(0))
            captureThread1 = New Thread(AddressOf CaptureData1)
            captureThread1.IsBackground = True
            captureThread1.Start()

        Else
            g_lDevID_1 = CLng(aryDeviceId(0))
            g_lDevID_2 = CLng(aryDeviceId(1))

            captureThread1 = New Thread(AddressOf CaptureData1)
            captureThread2 = New Thread(AddressOf CaptureData2)

            captureThread1.IsBackground = True
            captureThread2.IsBackground = True

            captureThread1.Start()
            Thread.Sleep(500)
            captureThread2.Start()

        End If

    End Sub

    ''' =========================== 📡 CAPTURE FUNCTION (Spectrometer 1) =========================== '''
    Private Sub CaptureData1()
        Try
            ' Open Spectrometer 1
            lReturn = obuMICROUSB2_1.MICRO_USB2_open(g_lDevID_1)
            If lReturn <> Usb2Struct.Cusb2Err.usb2Success Then Exit Sub

            ' ✅ Retrieve Calibration Coefficients for Spectrometer 1
            Dim coeffs1(6) As Double
            lReturn = obuMICROUSB2_1.MICRO_USB2_getCalibrationCoefficient(g_lDevID_1, 0, coeffs1)
            If lReturn <> Usb2Struct.Cusb2Err.usb2Success Then
                MessageBox.Show("Calibration retrieval failed for Spectrometer 1", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            Debug.WriteLine("Spectrometer 1 Coefficients: " & String.Join(",", coeffs1))
            A0_1 = coeffs1(0)
            B1_1 = coeffs1(1)
            B2_1 = coeffs1(2)
            B3_1 = coeffs1(3)
            B4_1 = coeffs1(4)
            B5_1 = coeffs1(5)

            ' Calculate Wavelengths for Spectrometer 1
            For pix As Integer = 0 To PIXEL_SIZE - 1
                wavelengths1(pix) = CalculateWavelength1(pix)
            Next
            Debug.WriteLine("Wavelengths for Spectrometer 1: " & String.Join(",", wavelengths1))

            ' ✅ Set Exposure Time
            lReturn = obuMICROUSB2_1.MICRO_USB2_setExposureTime(g_lDevID_1, EXPOSURE_TIME)
            If lReturn <> Usb2Struct.Cusb2Err.usb2Success Then Exit Sub

            While isCapturing
                ' Start Capture
                lReturn = obuMICROUSB2_1.MICRO_USB2_captureStart(g_lDevID_1)
                If lReturn <> Usb2Struct.Cusb2Err.usb2Success Then Exit Sub

                Thread.Sleep(500)

                ' Get Image Data
                lReturn = obuMICROUSB2_1.MICRO_USB2_getImageData(g_lDevID_1, aryusImageData, arylTime)
                If lReturn <> Usb2Struct.Cusb2Err.usb2Success Then Exit Sub

                Array.Copy(aryusImageData, capturedData1, PIXEL_SIZE)

                ' Display the graph for Spectrometer 1
                If Me.InvokeRequired Then
                    Me.Invoke(Sub() DisplayGraph1(capturedData1))
                Else
                    DisplayGraph1(capturedData1)
                End If

                obuMICROUSB2_1.MICRO_USB2_captureStop(g_lDevID_1)
                Thread.Sleep(500)
            End While

            ' Cleanup
            obuMICROUSB2_1.MICRO_USB2_captureStop(g_lDevID_1)
            obuMICROUSB2_1.MICRO_USB2_close(g_lDevID_1)

        Catch ex As Exception
            MessageBox.Show("Error in Spectrometer 1: " & ex.Message)
        End Try
    End Sub

    ''' =========================== 📡 CAPTURE FUNCTION (Spectrometer 2) =========================== '''
    Private Sub CaptureData2()
        Try
            ' Open Spectrometer 2
            lReturn = obuMICROUSB2_1.MICRO_USB2_open(g_lDevID_2)
            If lReturn <> Usb2Struct.Cusb2Err.usb2Success Then Exit Sub

            ' ✅ Retrieve Calibration Coefficients for Spectrometer 2
            Dim coeffs2(6) As Double
            lReturn = obuMICROUSB2_1.MICRO_USB2_getCalibrationCoefficient(g_lDevID_2, 0, coeffs2)
            If lReturn <> Usb2Struct.Cusb2Err.usb2Success Then
                MessageBox.Show("Calibration retrieval failed for Spectrometer 2", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            Debug.WriteLine("Spectrometer 2 Coefficients: " & String.Join(",", coeffs2))

            ' Assign coefficients
            A0_2 = coeffs2(0)
            B1_2 = coeffs2(1)
            B2_2 = coeffs2(2)
            B3_2 = coeffs2(3)
            B4_2 = coeffs2(4)
            B5_2 = coeffs2(5)

            ' Calculate Wavelengths for Spectrometer 2
            For pix As Integer = 0 To PIXEL_SIZE - 1
                wavelengths2(pix) = CalculateWavelength2(pix)
            Next
            Debug.WriteLine("Wavelengths for Spectrometer 2: " & String.Join(",", wavelengths2))

            ' ✅ Set Exposure Time
            lReturn = obuMICROUSB2_1.MICRO_USB2_setExposureTime(g_lDevID_2, EXPOSURE_TIME)
            If lReturn <> Usb2Struct.Cusb2Err.usb2Success Then Exit Sub

            While isCapturing
                ' Start Capture
                lReturn = obuMICROUSB2_1.MICRO_USB2_captureStart(g_lDevID_2)
                If lReturn <> Usb2Struct.Cusb2Err.usb2Success Then Exit Sub

                Thread.Sleep(500)

                ' Get Image Data
                lReturn = obuMICROUSB2_1.MICRO_USB2_getImageData(g_lDevID_2, aryusImageData, arylTime)
                If lReturn <> Usb2Struct.Cusb2Err.usb2Success Then Exit Sub

                Array.Copy(aryusImageData, capturedData2, PIXEL_SIZE)

                'Debug.WriteLine("Spectrometer 2 Data: " & String.Join(",", capturedData2))

                ' Display the graph for Spectrometer 2
                If Me.InvokeRequired Then
                    Me.Invoke(Sub() DisplayGraph2(capturedData2))
                Else
                    DisplayGraph2(capturedData2)
                End If

                obuMICROUSB2_1.MICRO_USB2_captureStop(g_lDevID_2)
                Thread.Sleep(500)
            End While

            ' Cleanup
            obuMICROUSB2_1.MICRO_USB2_captureStop(g_lDevID_2)
            obuMICROUSB2_1.MICRO_USB2_close(g_lDevID_2)

        Catch ex As Exception
            MessageBox.Show("Error in Spectrometer 2: " & ex.Message)
        End Try
    End Sub
    ''' =========================== 📈 DISPLAY GRAPH FOR SPECTROMETER 1 =========================== '''
    Private Sub DisplayGraph1(data() As UShort)
        If Chart1.InvokeRequired Then
            Chart1.Invoke(New Action(Sub() DisplayGraph1(data)))
            Return
        End If

        Chart1.Series.Clear()
        Chart1.ChartAreas.Clear()

        ' Create a new chart area
        Dim chartArea As New ChartArea()
        Chart1.ChartAreas.Add(chartArea)

        ' Customize chart labels
        Chart1.Titles.Clear()
        Chart1.Titles.Add("Spectrometer 1 Data")
        Chart1.Titles(0).Font = New Font("Arial", 14, FontStyle.Bold)

        ' Set X and Y axis labels
        chartArea.AxisX.Title = "Wavelength (nm)"
        chartArea.AxisX.TitleFont = New Font("Arial", 12, FontStyle.Bold)
        chartArea.AxisY.Title = "Intensity"
        chartArea.AxisY.TitleFont = New Font("Arial", 12, FontStyle.Bold)

        SetupZoomAndPan(chartArea)

        ' ✅ Connect Mouse Wheel Zoom & Double Click Reset
        AddHandler Chart1.MouseWheel, AddressOf Chart_MouseWheel
        AddHandler Chart1.DoubleClick, AddressOf Chart_DoubleClick

        chartArea.AxisX.Interval = 10.0

        ' Create and configure the series
        Dim series As New Series("Spectrometer 1") With {
        .ChartType = SeriesChartType.Line,
        .BorderWidth = 2,
        .Color = Color.Blue
        }
        ' Add all wavelength points with markers
        'For i As Integer = 0 To data.Length - 1
        '    Dim point As New DataPoint(wavelengths1(i), data(i))
        '    point.ToolTip = "Wavelength: " & wavelengths1(i) & " nm, Intensity: " & data(i)
        '    series.Points.Add(point)
        'Next

        For i As Integer = 0 To data.Length - 1
            If wavelengths1(i) Mod 10 = 0 Then
                Dim point As New DataPoint(wavelengths1(i), data(i))
                point.ToolTip = "Wavelength: " & wavelengths1(i) & " nm, Intensity: " & data(i)
                series.Points.Add(point)
            End If
        Next

        ' Add series to the chart
        Chart1.Series.Add(series)

        ' ✅ Force chart to refresh
        Chart1.Invalidate()
        Chart1.Update()
    End Sub

    ''' =========================== 📈 DISPLAY GRAPH FOR SPECTROMETER 2 =========================== '''
    Private Sub DisplayGraph2(data() As UShort)
        If Chart2.InvokeRequired Then
            Chart2.Invoke(New Action(Sub() DisplayGraph2(data)))
            Return
        End If

        Chart2.Series.Clear()
        Chart2.ChartAreas.Clear()

        ' Create a new chart area
        Dim chartArea As New ChartArea()
        Chart2.ChartAreas.Add(chartArea)

        ' Customize chart labels
        Chart2.Titles.Clear()
        Chart2.Titles.Add("Spectrometer 2 Data") ' ✅ Add Chart Title
        Chart2.Titles(0).Font = New Font("Arial", 14, FontStyle.Bold)

        ' Set X and Y axis labels
        chartArea.AxisX.Title = "Wavelength (nm)"
        chartArea.AxisX.TitleFont = New Font("Arial", 12, FontStyle.Bold)
        chartArea.AxisY.Title = "Intensity"
        chartArea.AxisY.TitleFont = New Font("Arial", 12, FontStyle.Bold)

        SetupZoomAndPan(chartArea)

        ' ✅ Connect Mouse Wheel Zoom & Double Click Reset
        AddHandler Chart2.MouseWheel, AddressOf Chart_MouseWheel
        AddHandler Chart2.DoubleClick, AddressOf Chart_DoubleClick

        chartArea.AxisX.Interval = 20.0

        ' Create and configure the series
        Dim series As New Series("Spectrometer 2") With {
        .ChartType = SeriesChartType.Line,
        .BorderWidth = 2,
        .Color = Color.Red
        }

        For i As Integer = 0 To data.Length - 1
            If wavelengths2(i) Mod 10 = 0 Then
                Dim point As New DataPoint(wavelengths2(i), data(i))
                point.ToolTip = "Wavelength: " & wavelengths2(i) & " nm, Intensity: " & data(i)
                series.Points.Add(point)
            End If
        Next

        ' Add series to the chart
        Chart2.Series.Add(series)

        ' ✅ Force chart to refresh
        Chart2.Invalidate()
        Chart2.Update()
    End Sub
    ''' =========================== 🔢 CALCULATE WAVELENGTH FOR SPECTROMETER 1 =========================== '''
    Private Function CalculateWavelength1(i As Integer) As Integer
        Dim wavelength As Double = A0_1 + (B1_1 * i) + (B2_1 * i ^ 2) + (B3_1 * i ^ 3) + (B4_1 * i ^ 4) + (B5_1 * i ^ 5)
        Return CInt(Math.Round(wavelength))
    End Function

    '''' =========================== 🔢 CALCULATE WAVELENGTH FOR SPECTROMETER 2 =========================== '''
    Private Function CalculateWavelength2(i As Integer) As Integer
        ' Calculate the wavelength using the polynomial equation
        Dim wavelength As Double = A0_2 + (B1_2 * i) + (B2_2 * i ^ 2) + (B3_2 * i ^ 3) + (B4_2 * i ^ 4) + (B5_2 * i ^ 5)

        Return CInt(Math.Round(wavelength))
    End Function

    ''' =========================== 💾 SAVE CSV =========================== '''
    Private Sub BtnSaveCSV_Click(sender As Object, e As EventArgs) Handles BtnSaveCSV.Click
        If isCapturing Then
            MessageBox.Show("Stop capturing before saving!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        ' Ensure the user has entered a data type description
        Dim dataType As String = txtDataType.Text.Trim()
        If dataType = "" Then
            MessageBox.Show("Please enter the type of data being read before saving!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        ' Ensure both spectrometers have data
        If capturedData1.Length = 0 OrElse capturedData2.Length = 0 Then
            MessageBox.Show("No data available to save!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        ' Set File Path
        Dim savePath As String = "D:\Visual Studio\Spectrometre\Spectrometer_Data1.csv"
        Dim fileExists As Boolean = File.Exists(savePath)

        Try
            Using writer As New StreamWriter(savePath, True)
                If Not fileExists Then
                    writer.WriteLine("Wavelength1," & String.Join(",", wavelengths1) & "," & "Wavelength2," & String.Join(",", wavelengths2))
                End If

                writer.WriteLine(dataType & "," & String.Join(",", capturedData1) & "," & dataType & "," & String.Join(",", capturedData2))

            End Using

            MessageBox.Show("Data saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As IOException
            MessageBox.Show("Error: The file is in use. Please close it and try again.", "File Access Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Catch ex As Exception
            MessageBox.Show("Error saving file: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ''' =========================== 🔍 CHECK FILE LOCATION =========================== '''
    Private Sub BtnCheckFile_Click(sender As Object, e As EventArgs) Handles BtnCheckFile.Click
        ' Set the same path where the file was saved
        Dim filePath As String = "D:\Visual Studio\Spectrometre\Spectrometer_Data1.csv"

        ' Check if the file exists
        If File.Exists(filePath) Then
            ' Open the folder where the file is located and highlight the file
            Process.Start("explorer.exe", "/select," & filePath)
        Else
            ' If the file doesn't exist, show a warning
            MessageBox.Show("The file does not exist at the specified location: " & filePath, "File Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub
    ''' =========================== 🛑 STOP CAPTURE =========================== '''
    Private Sub BtnStop_Click(sender As Object, e As EventArgs) Handles BtnStop.Click
        If Not isCapturing Then
            MessageBox.Show("No capturing is in progress!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        isCapturing = False

        If captureThread1 IsNot Nothing AndAlso captureThread1.IsAlive Then
            captureThread1.Join(100)
            captureThread1 = Nothing
        End If

        If captureThread2 IsNot Nothing AndAlso captureThread2.IsAlive Then
            captureThread2.Join(100)
            captureThread2 = Nothing
        End If

        ' ✅ Close Devices to ensure proper cleanup
        'obuMICROUSB2_1.MICRO_USB2_captureStop(g_lDevID_1)
        'obuMICROUSB2_1.MICRO_USB2_close(g_lDevID_1)
        'obuMICROUSB2_1.MICRO_USB2_uninitialize()

        'obuMICROUSB2_2.MICRO_USB2_captureStop(g_lDevID_2)
        'obuMICROUSB2_2.MICRO_USB2_close(g_lDevID_2)
        'obuMICROUSB2_2.MICRO_USB2_uninitialize()

        ' ✅ Enable Buttons
        BtnStart.Enabled = True
        BtnStop.Enabled = False
        BtnSaveCSV.Enabled = True ' Enable Save after stopping
        lblStatus.Text = "Status: Stopped"

        MessageBox.Show("Capture stopped successfully for both spectrometers!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    ''' ================== 📌 FUNCTION TO SETUP ZOOM & PAN ================== '''
    Private Sub SetupZoomAndPan(ByVal chartArea As ChartArea)
        ' Enable Zooming on both X and Y axis
        chartArea.AxisX.ScaleView.Zoomable = True
        chartArea.AxisY.ScaleView.Zoomable = True

        ' Enable user selection zooming
        chartArea.CursorX.IsUserEnabled = True
        chartArea.CursorX.IsUserSelectionEnabled = True
        chartArea.CursorY.IsUserEnabled = True
        chartArea.CursorY.IsUserSelectionEnabled = True

        ' Allow Panning (Scrolling)
        chartArea.AxisX.ScrollBar.IsPositionedInside = True
        chartArea.AxisY.ScrollBar.IsPositionedInside = True

        ' Set the zoom type
        chartArea.AxisX.ScaleView.SmallScrollSize = 5
        chartArea.AxisY.ScaleView.SmallScrollSize = 5
    End Sub

    ''' ================== 📌 FUNCTION TO RESET ZOOM ================== '''
    Private Sub ResetZoom(chart As Chart)
        If chart.InvokeRequired Then
            chart.Invoke(New MethodInvoker(Sub() ResetZoom(chart)))
        Else
            Try
                chart.ChartAreas(0).AxisX.ScaleView.ZoomReset()
                chart.ChartAreas(0).AxisY.ScaleView.ZoomReset()
            Catch ex As Exception
                MessageBox.Show("Zoom Reset Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    ''' ================== 📌 FUNCTION TO HANDLE MOUSE ZOOM ================== '''
    Private Sub Chart_MouseWheel(sender As Object, e As MouseEventArgs) Handles Chart1.MouseWheel, Chart2.MouseWheel
        Dim chart As Chart = CType(sender, Chart)
        Dim xAxis As Axis = chart.ChartAreas(0).AxisX
        Dim yAxis As Axis = chart.ChartAreas(0).AxisY

        Try
            If e.Delta < 0 Then ' Scroll Down (Zoom Out)
                xAxis.ScaleView.ZoomReset()
                yAxis.ScaleView.ZoomReset()
            Else ' Scroll Up (Zoom In)
                Dim xMin As Double = xAxis.ScaleView.ViewMinimum
                Dim xMax As Double = xAxis.ScaleView.ViewMaximum
                Dim yMin As Double = yAxis.ScaleView.ViewMinimum
                Dim yMax As Double = yAxis.ScaleView.ViewMaximum

                Dim zoomFactor As Double = 0.8 ' Adjust zoom intensity

                xAxis.ScaleView.Zoom(xMin + (xMax - xMin) * (1 - zoomFactor) / 2,
                                 xMax - (xMax - xMin) * (1 - zoomFactor) / 2)
                yAxis.ScaleView.Zoom(yMin + (yMax - yMin) * (1 - zoomFactor) / 2,
                                 yMax - (yMax - yMin) * (1 - zoomFactor) / 2)
            End If
        Catch ex As Exception
            MessageBox.Show("Zoom Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ''' ================== 📌 FUNCTION TO HANDLE DOUBLE CLICK RESET ZOOM ================== '''
    Private Sub Chart_DoubleClick(sender As Object, e As EventArgs) Handles Chart1.DoubleClick, Chart2.DoubleClick
        Dim chart As Chart = CType(sender, Chart)
        ResetZoom(chart)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles BtnCheckFile.Click

    End Sub
End Class
