﻿Imports System.Windows.Forms

Module Program
    Sub Main()
        Application.EnableVisualStyles()
        Application.SetCompatibleTextRenderingDefault(False)
        Application.Run(New Form1()) ' Ensure Form1 exists
    End Sub
End Module
